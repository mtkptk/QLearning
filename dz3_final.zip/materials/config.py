FPS = 2
TILE_SIZE = 128
GREEN = (0, 128, 0)

chunk = 100
number_of_episodes = 7000