import config
from environment import Environment, Quit, Action
import numpy as np
import random
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

environment = Environment(f'maps/map.txt')

#kombinacije x, y koordinata * broj akcija (4)

q_tab = np.zeros(( len(environment.get_field_map())*len(environment.get_field_map()[0]), len(list(Action))))


def get_action_eps_greedy_policy(env, q_tab, st, eps):
    """
    Get an action using an epsilon-greedy policy.

    Parameters:
    - env: The environment.
    - q_tab: The Q-table.
    - st: The current state.
    - eps: Epsilon for exploration-exploitation trade-off.

    Returns:
    - The selected action.
    """
    prob = random.uniform(0, 1)
    a = env.get_random_action()
    return Action(np.argmax(q_tab[st])) if prob > eps else a

def train(num_episodes, max_steps, lr, gamma, eps_min, eps_max, eps_dec_rate, env):
    """
    Train the agent using Q-learning.

    Parameters:
    - num_episodes: Number of episodes to train.
    - max_steps: Maximum number of steps per episode.
    - lr: Learning rate.
    - gamma: Discount factor.
    - eps_min: Minimum exploration probability.
    - eps_max: Maximum exploration probability.
    - eps_dec_rate: Exploration probability decay rate.
    - env: The environment.

    Returns:
    - q_tab: The learned Q-table.
    - avg_returns: List of average returns per episode.
    - avg_steps: List of average steps per episode.
    """
    avg_returns = []
    avg_steps = []
    q_tab = np.zeros(( len(environment.get_field_map())*len(environment.get_field_map()[0]), len(list(Action))))

    for episode in range(num_episodes):
        avg_returns.append(0.)
        avg_steps.append(0)
        eps = eps_min + (eps_max - eps_min) * np.exp(-eps_dec_rate * episode)

        env.reset()
        st = env.get_agent_position()
        st = st[0] * len(environment.get_field_map()) + st[1]

        rew_cum = 0

        for step in range(max_steps):
            act = get_action_eps_greedy_policy(env, q_tab, st, eps)
            new_st, rew, done = env.step(Action(act))

            new_st = len(environment.get_field_map())*new_st[0] + new_st[1]
            
            q_tab[st][act.value] += lr * (rew + gamma * np.max(q_tab[new_st]) - q_tab[st][act.value])

            rew_cum += rew

            if done:
                
                avg_returns[-1] += rew_cum
                avg_steps[-1] += step + 1
                break

            st = new_st

    return q_tab, avg_returns, avg_steps

def evaluate(num_episodes, max_steps, env, q_tab):
    ep_rew_lst = []
    steps_lst = []

    for episode in range(num_episodes):

        env.reset()
        state = env.get_agent_position()
        state = state[0] * len(environment.get_field_map()) + state[1]

        step_count = 0
        episode_reward = 0

        for step in range(max_steps):
            action = np.argmax(q_tab[state])
            new_state, reward, done = env.step(Action(action))

            step_count += 1
            episode_reward += reward

            if done:
                break
            
            new_state = new_state[0] * len(environment.get_field_map()) + new_state[1]
            state = new_state

        ep_rew_lst.append(episode_reward)
        steps_lst.append(step_count)

    print(f'TEST Mean reward: {np.mean(ep_rew_lst):.2f}')
    print(f'TEST STD reward: {np.std(ep_rew_lst):.2f}')
    print(f'TEST Mean steps: {np.mean(steps_lst):.2f}')

def line_plot(data, name, show):
    # Create a figure with a title indicating the average value
    plt.figure(f'Average {name} per episode: {np.mean(data):.2f}')
    
    # Create a DataFrame for plotting
    df = pd.DataFrame({
        name: [np.mean(data[i * config.chunk:(i + 1) * config.chunk])
               for i in range(config.number_of_episodes // config.chunk)],
        'episode': [config.chunk * i
                    for i in range(config.number_of_episodes // config.chunk)]
    })
    
    # Plot the data using seaborn
    plot = sns.lineplot(data=df, x='episode', y=name, marker='o', markersize=5, markerfacecolor='red')
    
    # Save the plot as an image
    plot.get_figure().savefig(f'{name}.png')
    
    # Optionally show the plot
    if show:
        plt.show()


q_tab, avg_returns, avg_steps = train(7000, 100, 0.05, 0.95, 0.005, 1.0, 0.001, environment)

#evaluate(7000, 100, environment, q_tab)

line_plot(avg_returns, "rewards", True)
line_plot(avg_steps, "steps", True)

try:
    environment.reset()
    environment.render(config.FPS)
    while True:

        st = environment.get_agent_position()
        st = st[0] * len(environment.get_field_map()) + st[1]

        action = Action(np.argmax(q_tab[st]))
        _, _, done = environment.step(action)
        environment.render(config.FPS)
        if done:
            break
except Quit:
    pass
